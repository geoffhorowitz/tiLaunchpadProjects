/*
 * reverse_and_rotate.c
 *
 *  Created on: Nov 13, 2016
 *      Author: geoff
 */




